cd -- "$(find -iname starter -type d)"
cd ..
rm -rf -- "$(pwd -P)"
cd ..