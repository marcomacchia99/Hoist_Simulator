 cd -- "$(find . -iname starter -type d)"

 ./starter